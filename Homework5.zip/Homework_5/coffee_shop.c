#include <stdio.h>
#include <stdlib.h>
#include "coffee_calculator.h"
#include <string.h>
#define ITEMS 51


int main(int argc, char* argv[]) {

    //End program if it doesn't contain any months within the command line
    if(argc == 1) {
        printf("Not enough arguments in command line.\n");
        return 1;
    }

    // allocate arrays to store 6 months of data
    int month_data[ITEMS][argc]; //data with item tags and items sold in each month

    // initialize money and month_data to zeros in each index
    for (int i = 0; i < argc; i ++){
        for (int j = 0; j < ITEMS; j++){
            month_data[j][i] = 0;
        }
    }
    //Sets first row to be the item code identifiers
    for(int i = 0; i <51; i++) {
            month_data[i][0] = i;
        }
    
    int new_item;
    float cost;
    char* detect = argv[1];
    //loop over all months
    for (int i = 1; i < argc; i++){
        FILE* f1;
        // open sales file
        detect = argv[i];
        
        if(strcmp(detect, "Jan_data.txt") == 0) {
            f1 = fopen("Jan_data.txt", "r");
        }
        else if (strcmp(detect, "Feb_data.txt") == 0) {
            f1 = fopen("Feb_data.txt", "r");           
        }
        else if (strcmp(detect, "Mar_data.txt") == 0) {
            f1 = fopen("Mar_data.txt", "r");            
        }
        else if (strcmp(detect, "Apr_data.txt") == 0) {
            f1 = fopen("Apr_data.txt", "r");            
        }
        else if (strcmp(detect, "May_data.txt") == 0) {
            f1 = fopen("May_data.txt", "r");           
        }
        else if (strcmp(detect, "Jun_data.txt") == 0) {
            f1 = fopen("Jun_data.txt", "r");           
        }
        else {
            printf("No file currently exists.\n");
            return 1;
        }
              
        // load sales data
        while(fscanf(f1, "%d %f", &new_item, &cost) == 2){
            
            //Sets values of how much of that item is sold in that month
            month_data[new_item][i] = month_data[new_item][i] +1;
            
        }
        fclose(f1);
    
    } // end loop over months
  
    //Pointers to the arrays in heaps
    float* costsArrayPtr = readCosts(51);
    float* purchArrayPtr = readPurch(51);

    //Sets every index value from the arrays in the heap to an array in the main stack
    float costArray[51];
    float purchArray[51];
    for(int i = 0; i < 51; i++) {
        costArray[i] = costsArrayPtr[i];
    }
    for(int i = 0; i < 51; i++) {
        purchArray[i] = purchArrayPtr[i];
    }
    free(costsArrayPtr);
    free(purchArrayPtr);

    //Calling methhods
    get_totals(argc, 51, month_data);
    get_profits(argc, 51, month_data, costArray, purchArray);
    top_earner(argc, 51, month_data, costArray, purchArray);

    //free and deallocate memory
    free(detect);
    
    return 0;
}