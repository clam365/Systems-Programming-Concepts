void get_totals(int rows, int col, int data[][rows]);
void get_profits(int rows, int col, int data[][rows], float costs[], float purch[]);
void top_earner(int rows, int col, int data[][rows], float costs[], float purch[]);

//new prototypes
float* readCosts(int numItems);
float* readPurch(int numItems);
