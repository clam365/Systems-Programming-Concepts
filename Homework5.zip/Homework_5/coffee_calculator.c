#include <stdio.h>
#include <stdlib.h>
#include "coffee_calculator.h"

/*
* void get_totals(int rows, int columns, int data[][rows])
* Determines the total sales in the variable months inputted by user 
*
* Input: 
*   - int data[][rows] : array containing item codes and data for variable months
*   - int rows + int columns basically says it
*
* Output:
*   - prints out the item code and amounts sales in each in the Total_sales.txt file
*/
void get_totals(int rows, int columns, int data[][rows]) {
    FILE* totals = fopen("Total_sales.txt", "w");
    
    // Nested For Loop that Adds every value to the output text file
    for (int i = 1; i < columns; i++) {
        int itemcode = data[i][0];
        int counter = 0;

        //Reads through every month for specific amount of itemcodes sold (Jan-June)
        for (int j = 1; j < rows; j++) {
                counter = counter + data[i][j];
        }
        //Prints out into Total_sales.txt
        fprintf(totals, "%2d%7d\n", itemcode, counter);
    }
    fclose(totals);
}

/*
* void get_profits(int rows, int col, int data[][rows], float costs[], float purch[]) 
* Determines the total profits in the variable inputted months for each item code
*
* Input: 
*   - int data[][rows] : array containing item codes and data for thee variable inputted months
*   - int rows + int columns, basically unneeded but determines the rows and columns in the array
*   - float costs[] : array containing the costs for each item code
*   - float purch[] array containing the revenue for each item code
*
* Output:
*   - prints out the item code, amount sold, revenue, costs, and profit in each in the Profits.txt file
*/
void get_profits(int rows, int col, int data[][rows], float costs[], float purch[]) {
    FILE* profits = fopen("Profits.txt", "w");
    float sale = 0.0;
    float cost = 0.0;
    
    fprintf(profits, "%s", "    Item       #   Sales    Cost Revenue\n");
    
    //Loop that goes through each item row
    for (int i = 1; i < col; i++) {
        int itemcode = data[i][0];
        int amountsold = 0;    

        // Loop that finds total amount sold in the last 6 month span    
        for (int j = 1; j < rows; j++) {
            amountsold = amountsold + data[i][j];
        }

        //Calculates the sales, costs, and then prints out all of those including the profit
        sale = purch[itemcode] * amountsold;
        cost = costs[itemcode] * amountsold;
        fprintf(profits, "%8d%8d%8.2f%8.2f%8.2f\n", itemcode, amountsold, sale, cost, sale - cost);
    }
    
    fclose(profits);
}

/*
* void top_earner(int rows, int col, int data[][rows], float costs[], float purch[]) 
* Determines the top ten items that have had the most profit from the variable inputted months
*
* Input: 
*   - int data[][rows] : array containing item codes and data for variable inputted months
*   - int rows + int columns, basically unneeded but determines the rows and columns in the array
*   - float costs[] : array containing the costs for each item code
*   - float purch[] array containing the revenue for each item code
*
* Output:
*   - prints out the top ten items with the greatest profit in the Top_earners.txt file
*/
void top_earner(int rows, int col, int data[][rows], float costs[], float purch[]) {
    FILE* tierlist = fopen("Top_earners.txt", "w");

    //51x2 array that contains the ints of the itemcode and the amount sold with each item
    int itemsandamount[51][2];
    for(int i = 0; i < col; i++) {
        itemsandamount[i][0] = i;
        int amountsold = 0;
        for(int j = 1; j < rows; j++) {
            amountsold = amountsold + data[i][j];
        }
        itemsandamount[i][1] = amountsold;
    }

    //51x1 array that contains the floats/profits of each item code respective to how much is sold
    float profits[51];
    for(int i = 0; i < col; i++) {
        //Amount sold * (revenue - cost)
        profits[i] = itemsandamount[i][1] * (purch[i] - costs[i]);
    }

    //Finally printing out the comparisons to make top 10
    fprintf(tierlist, "%s", "Item   #  Revenue\n");
    for(int i = 0; i < 10; i++){
        int maxindex = 0;
        //Inner for-loop finds the greatest # with its respective itemcode
        for(int j = 0; j < 51; j++){
            if(profits[j] > profits[maxindex]) {
                maxindex = j;
            }
        }
        fprintf(tierlist, "%4d%4d%9.2f\n", itemsandamount[maxindex][0], itemsandamount[maxindex][1], profits[maxindex]);
        //Sets the top thing to 0, insuring that a new max is to be found next iteration
        profits[maxindex] = 0;
    }

    fclose(tierlist);
}

/*
* float* readCosts(int numItems)
* Creates an array in the heap containing the costs for each item code, and returns a pointer to that array in the heap
*
* Input
*   - int numItems: the number of items being looked at
* Output
*   - pointer to the array in the heap
*/
float* readCosts(int numItems) {
    //Using malloc to set costs array to heap
    float* costsPtr = malloc(sizeof(float) * numItems);

    //Declaring stuff to be read in the text file
    int itemcode;
    float purchase = 0.0;
    float cost = 0.0;

    FILE* costsfile = fopen("Costs.txt", "r");
    while(fscanf(costsfile, "%i %f %f", &itemcode, &purchase, &cost) > 0){
        costsPtr[itemcode] = cost;
    }
    fclose(costsfile);

    return costsPtr;
}

/*
* float* readPurch(int numItems)
* Creates an array in the heap containing the revenue for each item code, and returns a pointer to that array in the heap
*
* Input
*   - int numItems: the number of items being looked at
* Output
*   - pointer to the array in the heap
*/
float* readPurch(int numItems) {
    //Using malloc to set purchase array to heap
    float* purchPtr = malloc(sizeof(float) *numItems);

    //Declaring stuff to be read in the text file
    int itemcode;
    float purchase = 0.0;
    float cost = 0.0;

    FILE* costsfile = fopen("Costs.txt", "r");
    while(fscanf(costsfile, "%i %f %f", &itemcode, &purchase, &cost) > 0){
        purchPtr[itemcode] = purchase;
    }
    fclose(costsfile);

    return purchPtr;
}


