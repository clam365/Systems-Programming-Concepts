Homework #6 Part 2
Written by Christopher Lam
WROTE PROGRAM ALONE

-program is designed to show inheritance between the parent class of an Animal and its derived class "Cat"

FILES USED:
1. Animal.cpp (parent class)
2. Animal.h (parent header)
3. Cat.cpp (derived class)
4. Cat.h (derived header)
5. test_cat.cpp (main)

HOW TO RUN:
1. First have all the files in one singular folder. Terminal must be to that folder.
2. Run with g++ -Wall test_cat.cpp Cat.cpp Animal.cpp -lm –o runCat 
    - if that does not work, use that line without -o runCat and then run with .\a.exe
3. BOOMBEY

CITING SOURCES: n/a