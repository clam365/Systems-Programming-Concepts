#include "Cat.h"


/*
* Cat::Cat(string tp, string c):Animal(c)
* constructor for a cat with input for its type
*/
Cat::Cat(string tp, string c):Animal(c){
    type = tp;
}


/*
* Cat::Cat():Animal("black")
* dafault constructor for a cat
*/
Cat::Cat():Animal("black"){
    type = "unk";
}


/*
* void Cat::setType(string tp)
* Set the type of cat
*
* Output: none
*/
void Cat::setType(string tp) {
    type = tp;
}


/*
* void Cat::displayInfo(string c)
* Display the Cat's characteristics
* 
* Output: type of cat and its color
*/
void Cat::displayInfo(string c) {
    cout << "I am a " << type << endl;
    cout << "My color is " << c << endl;
}


/*
* void Cat::meow()
* Literally prints out dialogue of the cat
*
* Output: "I can meow! Meow meow!"
*/
void Cat::meow() {
    cout << "I can meow! Meow meow!!" << endl;
}