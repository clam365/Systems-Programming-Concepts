Homework #6 Part 1
Written by Christopher Lam
WROTE PROGRAM ALONE

-program is designed to take in two text files of data which represent matrices and do addition and print it out to the Terminal
    - various instances of operator overloading through matrices addition and output through ostream

FILES USED:
1. run_matrix.cpp (main file)
2. Matrix.h (header file)
3. Matrix.cpp (added methods listed)
    - Matrix Matrix::operator+(Matrix &B)
        - operator addition overloading with MATRIX + MATRIX
    - Matrix operator+(float numbah)
        - operator addition overloading with MATRIX + FLOAT
    - Matrix operator+(float numbah, const Matrix& A)
        - operator addition overloading with FLOAT + MATRIX
    - ostream& operator<<(ostream& os, const Matrix& A)
        - instead of C.print(), method which allows to print matrix through cout

HOW TO RUN:
1. First have all the files in one singular folder. Terminal must be to that folder.
2. Run with g++ -Wall run_matrix.cpp Matrix.cpp -lm -o runM
3. BOOMBEY

CITING SOURCES: n/a