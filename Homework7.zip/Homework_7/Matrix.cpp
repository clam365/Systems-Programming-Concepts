#include <iostream>
#include <string>
#include <iomanip>

#include "Matrix.h"

Matrix::Matrix(int l1){
    length = l1;
    data = new float[length];
}

Matrix::Matrix(){
    length = 0;
    data = NULL;
}

void Matrix::readMatrix(string fileName) {
    ifstream input;
    input.open(fileName);
    
    for (int i = 0; i < length; i++){
        input >> data[i];
    }
    input.close();
}

/*******************************************************************************
* void print(Matrix& A){
*
* Output:
*   Prints A to the screen
********************************************************************************/

void Matrix::print(){

   // print values to screen
    for (int i = 0; i < length; i++){
       cout << std::setw(8) << data[i];  
    }
    printf("\n");

}

/*******************************************************************************
* Matrix::~Matrix()
*
* Deconstructor for Matrix object
********************************************************************************/
Matrix::~Matrix(){
    delete data;
}

int Matrix::getLength(){
    return length;
 }

float* Matrix::getData(){
    return data;
}

/*
* Matrix Matrix::operator+(Matrix &B)
* Operator Addition overloading to work with two matrices that are the same size
*
* Input: 
*   - Matrix &B: grabs matrix that will be added to the call
* Output: Resulting Matrix C after addition was completed
*/
Matrix Matrix::operator+(Matrix &B){
    Matrix C(length);
    for (int i = 0; i < length; i ++){
        C.data[i] = data[i] + B.data[i];
    }
    return C;
}


/*
* Matrix operator+(float numbah)
* Operator Addition Overloading to work with a Matrix + float
*
* Input: 
*   - float numbah: the number that will be added to all of the elements in the given matrix
*
* Output: new Matrix with the addition completed
*/
Matrix Matrix::operator+(float numbah)  {
    Matrix C(length);
    for(int i = 0; i < length; i++) {
        C.data[i] = data[i] + numbah;
    }
    return C;
}


/*
* Matrix operator+(float numbah, const Matrix& A)
* Operator Addition Overloading to work with a float + Matrix
*
* Input: 
*   - float numbah: the number that will be added to all of the elements in the matrix
*   - const Matrix& A: Matrix that will be added with the float
*
* Output: new Matrix with the addition completed
*/
Matrix operator+(float numbah, const Matrix& A) {
    int length = A.length;
    Matrix C(length);

    for(int i = 0; i < length; i++) {
        C.data[i] = A.data[i] + numbah;
    }
    return C;

}


/*
* ostream& operator<<(ostream& os, const Matrix& A)
* Overloads the ostream to allow the "cout << C << end" to pass and print a matrix instead of using C.print()
*
* Input: 
*   - ostream& os: class to allow print/outputs
*   - const Matrix& A: Matrix that will be outputted
*
* Output: prints out Matrix to terminal
*/
ostream& operator<<(ostream& os, const Matrix& A) {
    for(int i = 0; i < A.length; i++) {
        cout << std::setw(8) << A.data[i]; 
    }
    return os;
}
