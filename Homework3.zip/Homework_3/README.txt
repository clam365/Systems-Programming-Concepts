Homework #2
Written by Christopher Lam
WROTE PROGRAM ALONE

-program is designed to make a cheap cash register software using C language
-made with a header function file (coffee_shop_functions.h), the main file(coffee_shop.c), function file (coffee_shop_functions.c), connected with the makefile

HOW TO RUN:
1. First have all the files in one singular folder. Terminal must be to that folder.
2. Use makefile to connect the c source files and the header file.
    - Follow the commands one by one.
    - gcc -g -Wall coffee_shop.o coffee_shop_functions.o -lm -o sales.exe
    - gcc -g -Wall -c coffee_shop_functions.c
    - gcc -g -Wall -c coffee_shop.c
3. To run the the program, do the 'make' command, if Windows then mingw32-make.
    - after you may run the program with .\sales.exe
4. BOOMBEY

CITING SOURCES:
    - https://stackoverflow.com/questions/38685724/difference-between-ms-and-s-scanf
        - %ms reference when using it. This will help me so I don't have to have a predetermined char amount. %ms will do that for me by reading from the beginning then the end of file easily.
    - https://www.tutorialspoint.com/eof-getc-and-feof-in-c
        - instead of having to use a number for comparison in the forloop of the tally function, EOF just does the job easier.

