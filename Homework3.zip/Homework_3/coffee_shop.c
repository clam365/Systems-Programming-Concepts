#include <stdio.h> 
#include <stdlib.h> 
#include "coffee_shop_functions.h"


int main(void) {

    //The initil block scope variables
    int input;
    FILE* f1;
    char* typein;
   

    /* Prompting user for*/
    printf("Which program would you like to run: (1) Calculate overall revenue, (2) Calculate register balance, or (3) Calculate sales for an item.\n");
    scanf("%d", &input);

    /* Viable Options*/

        //Overall Revenue Method
        if (input == 1 ) {
            printf("Please enter an input file:\n");
            scanf(" %ms", &typein);
            
            f1 = fopen(typein, "r");
            printf("%0.2f\n", overall_revenue(f1));

            return 0;
        }

        //Register Balance Method
        else if (input == 2) {
            printf("Please enter an input file:\n");
            scanf(" %ms", &typein);

            f1 = fopen(typein, "r");
            printf("%0.2f\n", balance(f1));
            
            return 0;
        }
        
        //Tally Method
        else if (input == 3) {
            int analyze;
            // Prompt user for input file
            printf("Please enter an input file:\n");
            scanf(" %ms", &typein);
            f1 = fopen(typein, "r");

            //Asking which thing to analyze
            
            printf("Which item to analyze?\n");
            scanf("%d", &analyze);
            tally(f1, analyze);
        }
         
        /*If the input is not 1, 2, or 3, end program*/
        else {
            printf("This option is not valid.");
            return 0;
        }
}
