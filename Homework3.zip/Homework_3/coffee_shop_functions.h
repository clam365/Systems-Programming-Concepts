float overall_revenue(FILE* f1);
float balance(FILE* f1);
int tally(FILE* f1, int item);