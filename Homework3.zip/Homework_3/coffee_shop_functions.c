#include <stdio.h> 
#include <stdlib.h> 
#include "coffee_shop_functions.h"
#include <stdbool.h>

/*
* float overall_revenue(FILE* f1)
* Determines the overall revenue of the day from an input file with its item codes and price of item
* Input: FILE* f1 (text file)
* Output: float (which is the revenue not including the register balance)
*/
float overall_revenue(FILE* f1) {
    float totalrevenue= 0.0;
    int item;
    float itemprice; 
    bool firstline = true;
    float registerbalance = 0.0;

    while(fscanf(f1, "%d %f", &item, &itemprice) == 2) {
        while(firstline == true) {
            firstline = false;
            registerbalance = registerbalance + itemprice;
        }
        totalrevenue = totalrevenue + itemprice;
    }
    fclose(f1);
    return totalrevenue - registerbalance;
    
    
   
}

/*
* float balance(FILE* f1)
* Determines the overall balance of the day from an input file with its item codes and price of item
* Input: FILE* f1 (text file)
* Output: float (which is the revenue of the day plus the register balance
*
* SOURCES: %ms located in the README.txt
*/
float balance(FILE* f1) {
    int item;
    float totalbalance;
    float itemprice;

    while(fscanf(f1, "%d" "%f", &item, &itemprice) == 2) {
        totalbalance = totalbalance + itemprice;
    }
    fclose(f1);
    return totalbalance;
}

/*
* int tally(FILE* f1, int)
* Determines the amount of times a specific number an item(with its code) has been sold 
* Input: FILE* f1 (text file), int item(the code)
* Output: returns an integer which is the # of times the item has been sold
*    - in a separate text file whether it's created or not, it will also output the item code and how many times it's been sold in a table format
*
* SOURCES: EOF in the README.txt
*/
int tally(FILE* f1, int item) {
    int counter = 0;
    float itemrevenue = 0.0;
    int itemnumber = item;

    float itemprice;

    char* outputfile;
    char optionAorO;
    FILE* f2;

    //Asking user where to put this output           
    printf("What is the output file?\n");
    scanf(" %ms", &outputfile);

    //Options of Append or Overwrite
    printf("Enter A for Append or O for over-write.\n");
    scanf(" %c", &optionAorO);
            
        if(optionAorO == 'A') {
            f2 = fopen(outputfile, "a");
        }
        else if(optionAorO == 'O') {
            f2= fopen(outputfile, "w");
        }
        else {
            printf("%s", "This option is not valid.");
            return 0; 
        } 

        while(fscanf(f1, "%d %f", &item, &itemprice) != EOF) {
            if(itemnumber == item) {
                counter++;
                itemrevenue = itemrevenue + itemprice;
            }
        }

        fprintf(f2, "%3d%4d\n", itemnumber, counter);
        fclose(f1);

    return counter;
}
