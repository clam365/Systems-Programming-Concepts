void get_total(int[][7], int, int);
void get_profits(int[][7], int, int, float[][2]);
void top_earner(int[][7], int, int, float[][2]);