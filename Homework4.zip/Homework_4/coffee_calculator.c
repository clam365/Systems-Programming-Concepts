#include <stdio.h>
#include <stdlib.h>
#include "coffee_calculator.h"


/*
* void get_total(int [][7], int, int)
* Determines the total sales in the past 6 months for each item code
*
* Input: 
*   - int data[][7] : array containing item codes and data for past 6 months
*   - int rows + int columns, basically unneeded but determines the rows and columns in the array
*
* Output:
*   - prints out the item code and amounts sales in each in the Total_sales.txt file
*/
void get_total(int data[][7], int rows, int columns) {
    FILE* totals = fopen("Total_sales.txt", "w");
    
    // Nested For Loop that Adds every value to the output text file
    for (int i = 0; i < columns; i++) {
        int itemcode = data[i][0];
        int counter = 0;

        //Reads through every month for specific amount of itemcodes sold (Jan-June)
        for (int j = 1; j < rows; j++) {
                counter = counter + data[i][j];
        }
        //Prints out into Total_sales.txt
        fprintf(totals, "%2d%7d\n", itemcode, counter);
    }
    fclose(totals);
}

/*
* void get_profits(int [][7], int, int, float[][])
* Determines the total profits in the past 6 months for each item code
*
* Input: 
*   - int data[][7] : array containing item codes and data for past 6 months
*   - int rows + int columns, basically unneeded but determines the rows and columns in the array
*   - float data2[][2]: array containing item codes and each costs and revenue of that itemcode
*
* Output:
*   - prints out the item code, amount sold, revenue, costs, and profit in each in the Profits.txt file
*/
void get_profits(int data[][7], int rows, int columns, float data2[][2]) {
    FILE* profits = fopen("Profits.txt", "w");
    float sales = 0.0;
    float costs = 0.0;
    
    fprintf(profits, "%s", "    Item       #   Sales    Cost Revenue\n");
    data[26][0] = 26;
    //Loop that goes through each item row
    for (int i = 1; i < columns; i++) {
        int itemcode = data[i][0];
        int amountsold = 0;    

        // Loop that finds total amount sold in the last 6 month span    
        for (int j = 1; j < rows; j++) {
            amountsold = amountsold + data[i][j];
        }

        //Calculates the sales, costs, and then prints out all of those including the profit
        sales = data2[itemcode][0];
        costs = data2[itemcode][1];
        fprintf(profits, "%8d%8d%8.2f%8.2f%8.2f\n", itemcode, amountsold, sales*amountsold, costs*amountsold, (sales*amountsold)-(costs*amountsold));
    }

    fclose(profits);
}



/*
* void top_earner(int [][7], int, int, float[][2])
* Determines the top ten items that have had the most profit
*
* Input: 
*   - int data[][7] : array containing item codes and data for past 6 months
*   - int rows + int columns, basically unneeded but determines the rows and columns in the array
*   - float data2[][2]: array containing item codes and each costs and revenue of that itemcode
*
* Output:
*   - prints out the top ten items with the greatest profit in the Top_earners.txt file
*/
void top_earner(int data[][7], int rows, int columns, float data2[][2]) {
    FILE* tierlist = fopen("Top_earners.txt", "w");

    //51x2 array that contains the ints of the itemcode and the amount sold with each item
    int itemsandamount[51][2];
    for(int i = 0; i < columns; i++) {
        itemsandamount[i][0] = i;
        int amountsold = 0;
        for(int j = 1; j < rows; j++) {
            amountsold = amountsold + data[i][j];
        }
        itemsandamount[i][1] = amountsold;
    }

    //51x1 array that contains the floats/profits of each item code respective to how much is sold
    float profits[51];
    for(int i = 0; i < columns; i++) {
        //Amount sold * (revenue - cost)
        profits[i] = itemsandamount[i][1] * (data2[i][0] - data2[i][1]);
    }

    //Finally printing out the comparisons to make top 10
    fprintf(tierlist, "%s", "Item   #  Revenue\n");
    for(int i = 0; i < 10; i++){
        int maxindex = 0;
        //Inner for-loop finds the greatest # with its respective itemcode
        for(int j = 0; j < 51; j++){
            if(profits[j] > profits[maxindex]) {
                maxindex = j;
            }
        }
        fprintf(tierlist, "%4d%4d%9.2f\n", itemsandamount[maxindex][0], itemsandamount[maxindex][1], profits[maxindex]);
        //Sets the top thing to 0, insuring that a new max is to be found next iteration
        profits[maxindex] = 0;
    }

    fclose(tierlist);

}


