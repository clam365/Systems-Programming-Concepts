Homework #3
Written by Christopher Lam
WROTE PROGRAM ALONE

-program is designed to calculate statistics of a coffee shop using C language
-made with a header function file (coffee_calculator.h), the main file(coffee_shop.c), function file (coffee_calculator.c), connected with the makefile

HOW TO RUN:
1. First have all the files in one singular folder. Terminal must be to that folder.
2. Use makefile to connect the c source files and the header file.
    - Follow the commands one by one.
    - gcc -g -Wall coffee_shop.o coffee_calculator.o -lm -o analysis.exe
    - gcc -g -Wall -c coffee_calculator.c
    - gcc -g -Wall -c coffee_shop.c
3. To run the the program, do the 'make' command, if Windows then mingw32-make.
    - after you may run the program with .\analysis.exe
4. BOOMBEY

CITING SOURCES: n/a used 
