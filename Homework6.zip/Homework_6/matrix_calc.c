#include <stdlib.h>
#include <stdio.h>
#include "matrix_math.h"
#include <string.h>

int main(int argc, char* argv[]) {

    //End program if it doesn't contain the right amount of arguments
    if(argc != 4) {
        printf("Wrong number of arguments inputted.\n");
        return 1;
    }

    //User decision on whether to add or subtract matrices
    char* decision = argv[3];

    //Declaring matrices
    Matrix* pointerA = readMatrix(argv[1]);
    Matrix* pointerB = readMatrix(argv[2]);

    //Checking whether matrices sizes are compatible
    if (pointerA->size != pointerB->size) {
        printf("This math cannot be performed.\n");
        return 1;
    }
    //If matrices are compatible
    else {
        //Decision for adding matrices
        if (strcmp(decision, "a") == 0) {
            addMatrices(pointerA, pointerB);
        }
        //Decision for subtracting matrices
        else if (strcmp(decision, "s") == 0) {
            subtractMatrices(pointerA, pointerB);
        }
        //If decision is not = to "a" or "s" 
        else {
            printf("This math cannot be performed.\n");
            return 1;
        }
    }

    // Free/deallocate memory of the structs
    deleteMatrix(pointerA);
    free(pointerA);
    deleteMatrix(pointerB);
    free(pointerB);

    //End program
    return 0;
}



