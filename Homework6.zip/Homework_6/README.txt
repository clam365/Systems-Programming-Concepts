Homework #5
Written by Christopher Lam
WROTE PROGRAM ALONE

-program is designed to take in two text files of data which represent matrices and do addition and subtraction with them
    - uses command line arguments to proccess easier and allow input of data 
-made with a header function file (matrix_math.h), the main file(matrix_calc.c), function file (matrix_math.c), connected with the makefile

HOW TO RUN:
1. First have all the files in one singular folder. Terminal must be to that folder.
2. Use makefile to connect the c source files and the header file.
    - Follow the commands one by one (with mingw32-make)
        - mingw32-make matrix_calc.o
        - mingw32-make matrix_math.o
        - mingw32-make matric_calc
        - mingw32-make
3. To run the program, choose either of the two (first is addition, second is subtraction)
   (data1.txt and data2.txt represent your inputs, you can choose different text files as long as they follow the same format of the # of elements at the top
   and then the elements in the bottom line)
    - .\matrixCalc.exe data1.txt data2.txt a 
    - .\matrixCalc.exe data1.txt data2.txt s

4. BOOMBEY

CITING SOURCES: n/a used 