#include <stdlib.h>
#include <stdio.h>
#include "matrix_math.h"
#include <stdbool.h>


/*
* struct matrix* readMatrix(char* filename)
* allocate space for a struct matrix in the heap
*
* Inputs:
*   - char* filename: taking input from argv's which is a pointing to a text file
* Output:
*   - allocate space for a matrix and its contents
*/
struct matrix* readMatrix(char* filename) {
    FILE* f1 = fopen(filename, "r");

    int size;
    fscanf(f1, "%d", &size);

    //allocate space for heaps
    Matrix* pointer = malloc(sizeof(Matrix));
    pointer->size = size;
    pointer->data = malloc(size * sizeof(float));

    //Look at every element for the matrix
    for(int i = 0; i < size; i++){
        fscanf(f1, "%f", &pointer->data[i]);
    }

    fclose(f1);
    return pointer;
}

/*
* int deleteMatrix(Matrix *A)
* Deallocate memory of the structure and its contents
* 
* Input:
*   - Matrix *A: pointer to desired matrix
* Output: 
*   - returns an int indicating memory deallocation has been completed
*/
int deleteMatrix(Matrix *A) {
    free(A->data);
    return 1;
}

/*
* void addMatrices(Matrix *A, Matrix *B)
* Does matrices addition and outputs it to the terminal
*
* Inputs
*   - Matrix* A and Matrix *B : pointers to the two matrices involved in the addition (goes in A + B)
* Output
*   - prints out the initial (A + B = ), then the element addition in the new line
*/
void addMatrices(Matrix *A, Matrix *B) {
    printf("%s", "A + B = \n");
    int loopsize = A->size;

    //Looping through every element in array and printing it out with addition
    for (int i = 0; i < loopsize; i++) {
        printf("%9.2f", (A->data[i] + B->data[i]));
    }
}


/*
* void subtractMatrices(Matrix *A, Matrix *B)
* Does matrices subtraction and outputs it to the terminal
*
* Inputs
*   - Matrix* A and Matrix *B : pointers to the two matrices involved in the subtraction (goes in A - B)
* Output
*   - prints out the initial (A - B = ), then the element subtraction in the new line
*/
void subtractMatrices(Matrix *A, Matrix *B) {
    printf("%s", "A - B = \n");
    int loopsize = A->size;

    //Looping through every element in array and printing it out with subtraction
    for (int i = 0; i < loopsize; i++) {
        printf("%9.2f", (A->data[i] - B->data[i]));
    }
}