struct matrix {
    int size;
    float* data;
};

typedef struct matrix Matrix;

struct matrix* readMatrix(char* filename);
int deleteMatrix(struct matrix *A);
void addMatrices(Matrix *A, Matrix *B);
void subtractMatrices(Matrix *A, Matrix *B);